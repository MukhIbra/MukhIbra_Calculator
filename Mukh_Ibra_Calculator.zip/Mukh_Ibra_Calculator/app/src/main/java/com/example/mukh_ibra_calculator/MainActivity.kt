package com.example.mukh_ibra_calculator

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity(){
    private lateinit var operand: TextView
    private lateinit var result: TextView
    private lateinit var btnAdd: Button
    private lateinit var btnSubtract: Button
    private lateinit var btnMultiply: Button
    private lateinit var btnDivide: Button
    private lateinit var btnEqual: Button

    private lateinit var btnZero: Button
    private lateinit var btnOne: Button
    private lateinit var btnTwo: Button
    private lateinit var btnThree: Button
    private lateinit var btnFour: Button
    private lateinit var btnFive: Button
    private lateinit var btnSix: Button
    private lateinit var btnSeven: Button
    private lateinit var btnEight: Button
    private lateinit var btnNine: Button

    private lateinit var btnDot: Button
    private lateinit var btnClear: Button
    private lateinit var btnDel: Button
    private lateinit var plus_minus: Button
    private lateinit var percentage: Button


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        operand = findViewById(R.id.operand)
        result = findViewById(R.id.result)
        btnAdd = findViewById(R.id.btnAdd)
        btnSubtract = findViewById(R.id.btnSubtract)
        btnMultiply = findViewById(R.id.btnMultiply)
        btnDivide = findViewById(R.id.btnDivide)
        btnEqual = findViewById(R.id.btnEqual)

        btnZero = findViewById(R.id.zero)
        btnOne = findViewById(R.id.btnOne)
        btnTwo = findViewById(R.id.btnTwo)
        btnThree = findViewById(R.id.btnThree)
        btnFour = findViewById(R.id.btnFour)
        btnFive = findViewById(R.id.btnFive)
        btnSix = findViewById(R.id.btnSix)
        btnSeven = findViewById(R.id.btnSeven)
        btnEight = findViewById(R.id.btnEight)
        btnNine = findViewById(R.id.btnNine)

        btnDot = findViewById(R.id.dot)
        btnClear = findViewById(R.id.c)
        btnDel = findViewById(R.id.delete)
        plus_minus = findViewById(R.id.plus_minus)
        percentage = findViewById(R.id.percentage)



        btnOne.setOnClickListener {add("1") }
        btnTwo.setOnClickListener { add("2") }
        btnThree.setOnClickListener { add("3") }
        btnFour.setOnClickListener { add("4") }
        btnFive.setOnClickListener { add("5") }
        btnSix.setOnClickListener { add("6") }
        btnSeven.setOnClickListener { add("7") }
        btnEight.setOnClickListener { add("8") }
        btnNine.setOnClickListener { add("9") }
        btnZero.setOnClickListener { add("0") }
        btnDot.setOnClickListener { add(".") }

        btnDel.setOnClickListener { backspace() }
        plus_minus.setOnClickListener { negativePositive() }
        btnClear.setOnClickListener { clear() }
        btnAdd.setOnClickListener { amal("+") }
        btnSubtract.setOnClickListener { amal("-") }
        btnMultiply.setOnClickListener { amal("×") }
        btnDivide.setOnClickListener { amal("÷") }
        percentage.setOnClickListener{ percent() }

        btnEqual.setOnClickListener{equal()}
    }

    private var current = "0"
    private var all = ArrayList<String>()

    private fun hasPoint(): Boolean { return current.contains('.') }
    private fun hasAmal(): Boolean { return current == "" }
    private fun isNegative(): Boolean {return current[0] == '-'}

    private fun getAll(): MutableList<String> {return all.toMutableList()}
    private fun update() {
        operand.text = getTEXT()
        if (operand.text.length <= 10) operand.setTextSize(60F)
        else if (operand.text.length > 10) operand.setTextSize( TypedValue.COMPLEX_UNIT_SP, 32F)
        else if (operand.text.length > 18) operand.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24F)
        else if (operand.text.length > 28) operand.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
    }
    private fun setResult(){
        if (all.size > 0 && current != "") result.text = calculate() else result.text = ""
        result.text = space(result.text.toString())
    }


    private fun equal(){
        if (!result.text.isEmpty()){
            all.clear()
            current = result.text.toString().replace(" ", "")
            operand.text = space(current)
            result.text = ""
        }
    }

    private fun backspace(){
        if (current == "0" && all.size == 0) return
        if (current == "-") current = ""
        if (current != ""){
            current = current.substring(0, current.length-1)
            if (current == "" && all.size == 0) current = "0"
        }else{
            all.removeAt(all.size-1)
            current = all[all.size-1]
            all.removeAt(all.size-1)
        }
        if (current == "-") current = ""
        setResult()
        update()
    }

    private fun clear() {
        all.clear()
        current = "0"
        result.text = ""
        update()
    }

    private fun add(nima: String) {
        if (nima == "." && hasPoint()) return
        if (current == "0") current = ""
        if (nima == "." && current.isEmpty()) current += "0"
        current += nima
        setResult()
        update()
    }

    private fun amal(nima: String) {
        if (hasAmal()) {
            all.set(all.size - 1,nima)
            update()
            return
        }
        if (current.last() == '.') current = current.substring(0, current.length-1)
        all.add(current)
        all.add(nima)
        current = ""
        update()
    }

    private fun percent(){
        if (current == "") return
        if (all.size == 0) return
        if (all[all.size-1] != "÷") all[all.size-1] = "×"
        var myNum = current.toDouble()
        myNum /= 100
        current = myNum.toString()
        setResult()
        update()
    }

    private fun negativePositive(){
        if (current.isEmpty() || current == "0") return
        current = if (isNegative()) current.substring(1, current.length) else "-$current"
        setResult()
        update()
    }

    private fun calculate(): String {
        return step2(step1(getAll()))
    }

    private fun step1(list: MutableList<String>): MutableList<String> {
        if (!list.contains("÷") && !list.contains("×")) return list
        list.add(current)
        var j = 0
        while (j < list.size){
            val i = list[j]
            if (i == "÷" || i == "×"){
                val first = list[j-1].toDouble()
                val second = list[j+1].toDouble()
                val res:Double = if (i == "×") first*second
                else first/second
                list[j-1] = if ((res % 1).toFloat() == (0).toFloat()) res.toInt().toString() else res.toString()
                list.removeAt(j)
                list.removeAt(j)
                j-=2
            }
            j++
        }
        return list
    }

    private fun step2(list: MutableList<String>): String {
        if (!list.contains("+") && !list.contains("-")) return list[0]
        list.add(current)
        var j = 0
        while (j < list.size) {
            val i = list[j]
            if (i == "+" || i == "-") {
                val first = list[j - 1].toDouble()
                val second = list[j + 1].toDouble()
                val res: Double = if (i == "+") first + second
                else first - second
                list[j - 1] = if ((res % 1).toFloat() == (0).toFloat()) res.toInt()
                    .toString() else res.toString()
                list.removeAt(j)
                list.removeAt(j)
                j-=2
            }
            j++
        }
        return list[0]
    }

    private fun getTEXT(): String {
        var returnVal = ""
        if (all.size == 0) return space(current)
        for (j in all.indices) {
            val i = all[j]
            returnVal += if (i.length > 1 && i.contains('-') && j != 0) {
                "(${space(i)})"
            } else {
                space(i)
            }
        }
        returnVal += if (current.contains('-')) "(${space(current)})"
        else space(current)
        return returnVal
    }

    private fun space(nimA: String): String {
        var nima = nimA
        if (nima.length < 4) return nima
        var endIndex = nima.length-1
        if (nima.contains('.')){
            endIndex = nima.indexOf('.')-1
        }
        var index = endIndex - 2
        while (index > 0){
            if (nima[index-1] == '-') break
            val first = nima.substring(0, index)
            val last = nima.substring(index, nima.length)
            nima = "$first $last"
            index-= 3

        }
        return nima
    }
}